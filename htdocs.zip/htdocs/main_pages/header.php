<div class="header">
    <div class="Logoheader"></div>
    <div class="headerLineRight"></div>
    <div class="headerLineLeft"></div>
    <div class="Profilheader"></div>
    <div class="EraCoinheader"></div>
    <!-- <input type="search" class="form-control" placeholder="Search..." aria-label="Search"> 
<ul class="dropdown-menu text-small show" aria-labelledby="dropdownUser1" style="position: absolute; inset: auto auto 0px 0px; margin: 0px; transform: translate(0px, -34.4375px);" data-popper-placement="top-start">
            <li><a class="dropdown-item" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Новый проект...</font></font></a></li>
            <li><a class="dropdown-item" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Настройки</font></font></a></li>
            <li><a class="dropdown-item" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Профиль</font></font></a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">выход</font></font></a></li>
          </ul> -->
</div>